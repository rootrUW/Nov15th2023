/************************************************************** 
Title: Assignment06 Setup - Part 4
Description: This scipt create a view that shape the data to 
work with a MongoDB collection in assignment 06.
ChangeLog: When,Who,What
20201118,RRoot,Created Script
**************************************************************/

Use [DWNorthwindLite];
go

Create or Alter View vMongoDBExport
As
SELECT
 [OrderID] = 'TODO'
,[CustomerID] = 'TODO'
,[CustomerName] = 'TODO'
,[CustomerCity] = 'TODO'
,[CustomerCountry] = 'TODO'
,[Date] = 'TODO'
,[USADateName] = 'TODO'
,[ProductID] = 'TODO'
,[ProductName] = 'TODO'
,[ProductCategoryID] = 'TODO'
,[ProductCategoryName] = 'TODO'
,[ActualOrderUnitPrice] = 'TODO'
,[ActualOrderQuantity] = 'TODO'
,[ExtendedPrice] = 'TODO'
FROM [DWNorthwindLite].[dbo].[FactOrders]
go

--********************************************************************--
-- Review the results of this script
--********************************************************************--
Select * from vMongoDBExport;

