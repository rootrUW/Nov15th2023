Begin Try
	Use Master;
	If Exists(Select Name From SysDatabases Where Name = 'OutputDemos')
	 Begin 
	  Alter Database [OutputDemos] set Single_user With Rollback Immediate;
	  Drop Database [OutputDemos];
	 End
	Create Database [OutputDemos];
End Try
Begin Catch
	Print Error_Message();
End Catch
go
use OutputDemos;
go

Create Table [Table1] (ID varchar(10), Name varchar(100))
Insert Into Table1("ID", "Name")
Values (1, 'CatA'), ('2','CatB'), ('3','CatC')
go

With [CSV]
As (
Select 'CategoryID' + ',' + 'CategoryName' as [Data], 1 as [Sort]
Union
Select "ID" + ',' + "Name", 2 as [Sort]
 From Table1
)
Select [Data] From [CSV] Order By [Sort];
go

With [XML]
As (
Select (Select "ID" as [CategoryID], "Name" as [CategoryName]
        From Table1
        For xml raw('Category'), root('Categories')
		) as [Data]
)
Select [Data] From [XML];
go

With [JSON]
As (
Select '{"Categories":' as [Data], 1 as [Sort]
Union
Select (Select "ID" as [CategoryID], "Name" as [CategoryName]
 From Table1
 For json path), 2
Union
Select '}', 3 
)
Select [Data] From [JSON] Order by [Sort]
go

With HTML
AS
(
	Select '<html>' as [Data], 1 as [Sort]
	Union
	Select '<head><title>HTML Data</title></head>', 2 as [Sort]
	Union
	Select '<body>', 3 as [Sort]
	Union
	Select '<Table border="1">', 4 as [Sort]
	Union
	Select '<tr><th>CategoryID</th><th>CategoryName</th></tr>', 5 as [Sort]
	Union
	Select '<tr><td>' + "ID" + '</td><td>' + "Name" + '</td></tr>', 6 as [Sort]
	From Table1
	Union
	Select '</Table>', 7 as [Sort]
	Union
	Select '</body>', 8 as [Sort]
	Union
	Select '</html>', 8 as [Sort]
)
Select [Data] From HTML Order by [Sort]


Declare @BinaryData Table([BinaryID] varbinary(10), [BinaryName] varbinary(100))
Insert Into @BinaryData([BinaryID], [BinaryName])
  Select cast([ID] as varbinary(10)), cast([Name] as varbinary(100)) From Table1
Select [BinaryID], [BinaryName] From @BinaryData
go
