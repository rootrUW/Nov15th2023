import pickle # used to create binary files

row1 = {"ID": '1', "Name": 'CatA'}
row2 = {"ID": '2', "Name": 'CatB'}
row3 = {"ID": '3', "Name": 'CatC'}
table1 = [row1, row2, row3]

f = open("output.html", 'w')
f.write("- CSV"+'\n')
f.write("CategoryID,CategoryName\n")
for row in table1:
    f.write(row["ID"] + ',' + row["Name"] + '\n')

f.write("- XML"+'\n')
f.write('<Categories>\n')
for row in table1:
    f.write("<Category CategoryID='" + row["ID"] +" 'CategoryName='" + row["Name"] +"' />\n")
f.write('</Categories>\n')

f.write("- JSON"+'\n')
f.write('{"Categories": [ \n')
for row in table1:
    f.write('\t{"CategoryID":' + row["ID"] + ',' )
    f.write('"CategoryName":' + row["Name"] + '}\n')
f.write(']}\n')

f.write("- HTML"+'\n')
f.write('<html>\n <head>\n  <title>HTML Data</title>\n </head>\n')
f.write('<body>\n')
f.write('<table border="1">\n')
f.write('<tr><th>CategoryID</th><th>CategoryName</th></tr>\n')
for row in table1:
    f.write('\t<tr><td>' + row["ID"] + '</td><td>' + row["Name"] + '</td></tr>' + '\n')
f.write('</table>\n')
f.write('</body>\n')
f.write('</html>\n')

f.write("- Binary"+'\n')
f.close()
f = open("output.html", 'ab')
pickle.dump(table1, f)
f.close()