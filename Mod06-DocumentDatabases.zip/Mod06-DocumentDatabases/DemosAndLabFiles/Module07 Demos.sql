-- Mod 07 Demos

Use pubs;

go
Select * 
From pubs.dbo.titles as t
Order by t.title;
go

-- Reduce Title data and add Authors data
go
Select 
  t.[title_id]
, [title]
, a.*
From pubs.dbo.authors as a
Join pubs.dbo.titleauthor as ta
 On a.au_id = ta.au_id
Join pubs.dbo.titles as t
 On ta.title_id = t.title_id
Order by t.title, ta.au_ord;
go

-- Reduce Author data and add Publisher data
Select 
  [TitleID] = t.title_id
 ,[Title]
, [AuthorId] = Cast(a.au_id as nChar(11))
, [AuthorName] = Cast((au_fname + ' ' + au_lname) as nVarchar(100))
, [AuthorState] = Cast(a.state as nChar(2))
, [AuthorOrder] = ta.[au_ord]
, p.*
From pubs.dbo.authors as a
Join pubs.dbo.titleauthor as ta
 On a.au_id = ta.au_id
Join pubs.dbo.titles as t
 On ta.title_id = t.title_id
Join publishers as p
 On t.pub_id = p.pub_id
Order by t.title, ta.au_ord;
go

-- Reduce Publisher and add Sales data
Select 
  [TitleID] = t.title_id
, [Title]
, [Publisher] = p.pub_name
, [AuthorId] = Cast(a.au_id as nChar(11))
, [AuthorName] = Cast((au_fname + ' ' + au_lname) as nVarchar(100))
, [AuthorState] = Cast(a.state as nChar(2))
, [AuthorOrder] = ta.au_ord
, s.*
From pubs.dbo.authors as a
Join pubs.dbo.titleauthor as ta
 On a.au_id = ta.au_id
Join pubs.dbo.titles as t
 On ta.title_id = t.title_id
Join publishers as p
 On t.pub_id = p.pub_id
Join sales as s
 On t.title_id = s.title_id	
Order by t.title, ta.au_ord;
go


-- Reduce Sales data and add Stores
Select 
  [Title]
, [Publisher] = p.pub_name
, [AuthorId] = Cast(a.au_id as nChar(11))
, [AuthorName] = Cast((au_fname + ' ' + au_lname) as nVarchar(100))
, [AuthorState] = Cast(a.state as nChar(2))
, [AuthorOrder] = ta.au_ord
, [OrderNumber] = ord_num 
, [OrderDate] = Convert(varchar(50), ord_date, 112)
, [SalesQuantity] = qty
, st.*
From pubs.dbo.authors as a
Join pubs.dbo.titleauthor as ta
 On a.au_id = ta.au_id
Join pubs.dbo.titles as t
 on ta.title_id = t.title_id
Join publishers as p
 On t.pub_id = p.pub_id
Join sales as s
 On t.title_id = s.title_id	
Join stores as st
 On s.stor_id = st.stor_id
Order by t.title, ta.au_ord;
go

-- Reduce Store data
Select 
  [Title]
, [Publisher] = p.pub_name
, [AuthorId] = Cast(a.au_id as nChar(11))
, [AuthorName] = Cast((au_fname + ' ' + au_lname) as nVarchar(100))
, [AuthorState] = Cast(a.state as nChar(2))
, [AuthorOrder] = ta.au_ord
, [OrderNumber] = ord_num 
, [OrderDate] = Convert(varchar(50), ord_date, 110)
, [SalesQuantity] = qty
, [StoreId] = Cast(s.stor_id as nChar(4))
, [StoreName] = Cast(stor_name as nVarchar(50))
From pubs.dbo.authors as a
Join pubs.dbo.titleauthor as ta
 On a.au_id = ta.au_id
Join pubs.dbo.titles as t
 On ta.title_id = t.title_id
Join publishers as p
 On t.pub_id = p.pub_id
Join sales as s
 On t.title_id = s.title_id	
Join stores as st
 On s.stor_id = st.stor_id
Order by t.title, ta.au_ord;
go

-- Get only first authors
Select Cast((au_fname + ' ' + au_lname) as nVarchar(100)) as [FirstAuthor], title_id 
From titleauthor as ta join authors as a 
On ta.au_id = a.au_id
Where au_ord = 1

-- Get only second authors
Select Cast((au_fname + ' ' + au_lname) as nVarchar(100)) as [SecondAuthor], title_id
From titleauthor as ta join authors as a 
On ta.au_id = a.au_id
Where au_ord = 2

-- Get only thrid authors
Select Cast((au_fname + ' ' + au_lname) as nVarchar(100)) as [ThirdAuthor], title_id
From titleauthor as ta join authors as a 
On ta.au_id = a.au_id
 Where au_ord = 3

 -- Pivot Authors for titles
go
Create or Alter View vAuthorPivot As
With 
  AuOrd1 as (Select Cast((au_fname + ' ' + au_lname) as nVarchar(100)) as [FirstAuthor]
                  , title_id as TID1 
             From titleauthor as ta join authors as a 
			 On ta.au_id = a.au_id
			 Where au_ord = 1)
, AuOrd2 as (Select Cast((au_fname + ' ' + au_lname) as nVarchar(100)) as [SecondAuthor]
                  , title_id as TID2  
             From titleauthor as ta join authors as a
			 On ta.au_id = a.au_id
			 Where au_ord = 2)
, AuOrd3 as (Select Cast((au_fname + ' ' + au_lname) as nVarchar(100)) as [ThirdAuthor]
                  , title_id as TID3  
             From titleauthor as ta join authors as a 
			 On ta.au_id = a.au_id
			 Where au_ord = 3)
Select  
  Title
  ,IsNull(AuOrd1.FirstAuthor, 'Unknown') 
 + IsNull(' | ' + AuOrd2.SecondAuthor  , '') 
 + IsNull(' | ' + AuOrd3.ThirdAuthor , '') as [Authors]
from titles as t 
Left Join AuOrd1 
  On t.title_id = AuOrd1.TID1 
Left Join AuOrd2 
  On t.title_id = AuOrd2.TID2
Left Join AuOrd3 
  On t.title_id = AuOrd3.TID3
go


-- Get source data from pubs.dbo.Sales for FactSales
Create or Alter View vSalesDataForDocumentDB As
Select 
  [OrderNumber] = Cast(ord_num as nVarchar(50))
, [OrderDate] = Convert(varchar(50), ord_date, 110)
, [USDateName] = DateName(weekday, ord_date ) + ' ' + Convert(varchar(50), ord_date, 110)
, [TitleId] = Cast(isNull(t.[title_id], -1) as nvarchar(6))
, [TitleName] = Cast(isNull(t.[title], 'Unknown') as nvarchar(100))
--, [TitleName] = Replace(Cast(isNull(t.[title], 'Unknown') as nvarchar(100)), ',', '') --< REPLACE is used to Remove Comas
, [TitleType] = Case Cast([type] as nvarchar(50))
			When 'business' Then 'Business'
			When 'mod_cook' Then 'Modern Cooking' 
			When 'popular_comp' Then 'Popular Computing'			 
			When 'psychology' Then 'Psychology'				 
			When 'trad_cook' Then 'Traditional Cooking'	
			When 'UNDECIDED' Then 'Undecided'				     
		    End
, [TitlePrice] =  isNull('$' + Cast([price] as nvarchar(50)), 'Unknown') 
, [PublisherId] = Cast(p.pub_id as nChar(4))
, [PublisherName] = Cast(pub_name as nVarchar(50))
, [Authors] = ap.Authors
, [StoreId] = Cast(s.stor_id as nChar(4))
, [StoreName] = Cast(stor_name as nVarchar(50))
, [SalesQuantity] = qty
From pubs.dbo.sales as s 
Join pubs.dbo.stores as st
 On s.stor_id = st.stor_id
Join pubs.dbo.titles as t -- Note: This Inner Join will not show book that never sold
 On s.title_id = t.title_id 
Join pubs.dbo.publishers as p
 On t.pub_id = p.pub_id
Join vAuthorPivot as ap
 On t.title = ap.title
go

Select * From vSalesDataForDocumentDB

-- Now, open Excel, connect to the view, and save as a CSV file. 

