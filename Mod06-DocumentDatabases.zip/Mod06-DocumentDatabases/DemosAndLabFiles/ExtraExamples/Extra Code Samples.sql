-- CTEs --
Create View vRptSalesReportData
AS
With SalesByState AS
( -- Query 3: Calculate the percentage by individual state with a CTE
Select 
  [State] = state
 ,[Total By State] = Sum(Sales.qty)
 ,[Grand Total] = (Select Sum(Sales.qty) From Sales)
 ,[Percentage by State] = str((100 * Sum(Sales.qty)) / (Select Sum(Sales.qty) From Sales), 5, 2) + '%'
 From Pubs.dbo.Sales Join Pubs.dbo.Stores 
  On Stores.stor_id = Sales.stor_id
 Group by state
)
, SalesByStore AS
( -- Query 4: Calculate the percentage by individual store with a CTE
Select 
  [Store] = stor_name
 ,[State] = state
 ,[Total By Store] = Sum(Sales.qty)
 ,[Grand Total] = (Select Sum(Sales.qty) From Sales)
 ,[Percentage by Store] = str((100 * Sum(Sales.qty)) / (Select Sum(Sales.qty) From Sales), 5, 2) + '%'
 From Pubs.dbo.Sales Join Pubs.dbo.Stores 
  On Stores.stor_id = Sales.stor_id
 Group by stor_name, state
) -- Query 5: Join the two CTEs tables to create a complex report
Select 
   SS.Store
 , SS.State
 , SS.[Total By Store]
 , S.[Total By State]
 , S.[Grand Total]
 , SS.[Percentage By Store]
 , S.[Percentage by State]
From SalesByState as S
Join SalesByStore as SS
 on s.State = ss.State;
go
Declare @State char(2) = 'CA';
Select * From vRptSalesReportData;
Select * From vRptSalesReportData Where State = @State;
go


Create Function fRptSalesReportData(@State char(2) = null)
Returns @ReportData Table 
(Store varchar(50) Primary Key
,State char(2)
,[Total By Store] int
,[Total By State] int
,[Grand Total] int
,[Percentage By Store] varchar(50)
,[Percentage By State] varchar(50)
)
AS
 Begin 
    Declare @GrandTotal as int;
    Select @GrandTotal = Sum(Sales.qty) From Sales;
    With SalesByState AS
    ( -- Query 3: Calculate the percentage by individual state with a CTE
    Select 
      [State] = state
     ,[Total By State] = Sum(Sales.qty)
     ,[Grand Total] = @GrandTotal
     ,[Percentage by State] = str((100 * Sum(Sales.qty)) / @GrandTotal, 5, 2) + '%'
     From Pubs.dbo.Sales Join Pubs.dbo.Stores 
      On Stores.stor_id = Sales.stor_id
     Group by state
    )
    , SalesByStore AS
    ( -- Query 4: Calculate the percentage by individual store with a CTE
    Select 
      [Store] = stor_name
     ,[State] = state
     ,[Total By Store] = Sum(Sales.qty)
     ,[Grand Total] = @GrandTotal
     ,[Percentage by Store] = str((100 * Sum(Sales.qty)) / @GrandTotal, 5, 2) + '%'
     From Pubs.dbo.Sales Join Pubs.dbo.Stores 
      On Stores.stor_id = Sales.stor_id
     Group by stor_name, state
    ) -- Query 5: Join the two CTEs tables to create a complex report
    Insert Into @ReportData
    Select 
       SS.Store
     , SS.State
     , SS.[Total By Store]
     , S.[Total By State]
     , S.[Grand Total]
     , SS.[Percentage By Store]
     , S.[Percentage by State]
    From SalesByState as S
    Join SalesByStore as SS
     on s.State = ss.State
    Where s.State = @State OR @State is null
   Return
End
go
Select * From fRptSalesReportData(default);
Select * From fRptSalesReportData(Null);
Select * From fRptSalesReportData('CA');




go
Create Procedure pRptSalesReportData(@State char(2) = null)
AS
 Begin 
    Declare @GrandTotal as int;
    Select @GrandTotal = Sum(Sales.qty) From Sales;
   
    Select  -- Calculate the percentage by individual state with a CTE
      [State] = state
     ,[Total By State] = Sum(Sales.qty)
     ,[Grand Total] = @GrandTotal
     ,[Percentage by State] = str((100 * Sum(Sales.qty)) / @GrandTotal, 5, 2) + '%'
     Into #SalesByState
     From Pubs.dbo.Sales Join Pubs.dbo.Stores 
      On Stores.stor_id = Sales.stor_id
     Group by state

    Select -- Calculate the percentage by individual store with a CTE
      [Store] = stor_name
     ,[State] = state
     ,[Total By Store] = Sum(Sales.qty)
     ,[Grand Total] = @GrandTotal
     ,[Percentage by Store] = str((100 * Sum(Sales.qty)) / @GrandTotal, 5, 2) + '%'
     Into #SalesByStore
     From Pubs.dbo.Sales Join Pubs.dbo.Stores 
      On Stores.stor_id = Sales.stor_id
     Group by stor_name, state

    Select -- Join the two temp tables to create a complex report
       SS.Store
     , SS.State
     , SS.[Total By Store]
     , S.[Total By State]
     , S.[Grand Total]
     , SS.[Percentage By Store]
     , S.[Percentage by State]
    From #SalesByState as S
    Join #SalesByStore as SS
     on s.State = ss.State
    Where s.State = @State OR @State is null

    -- Return the other results as well!
    Select * From #SalesByState 
    Select * From #SalesByStore

   Return
End
go
Exec pRptSalesReportData default;
Exec pRptSalesReportData Null;
Exec pRptSalesReportData 'CA';

Select * From #SalesByState --< Causes an ERROR

go
Create Procedure pRptCreateSalesReportDataTables
AS
 Begin 
    Declare @GrandTotal as int;
    Select @GrandTotal = Sum(Sales.qty) From Sales;
    
    -- Drop tables as needed
    If Exists(Select * From Sys.tables Where name = 'tRptSalesByState') 
     Drop Table tRptSalesByState;
    If Exists(Select * From Sys.tables Where name = 'tRptSalesByStore') 
     Drop Table tRptSalesByStore;
    If Exists(Select * From Sys.tables Where name = 'tRptSalesByStoreAndState') 
     Drop Table tRptSalesByStoreAndState;

    -- Create reporting tables 
    Select  -- Calculate the percentage by individual state
      [State] = state
     ,[Total By State] = Sum(Sales.qty)
     ,[Grand Total] = @GrandTotal
     ,[Percentage by State] = str((100 * Sum(Sales.qty)) / @GrandTotal, 5, 2) + '%'
     Into tRptSalesByState
     From Pubs.dbo.Sales Join Pubs.dbo.Stores 
      On Stores.stor_id = Sales.stor_id
     Group by state;

    Select -- Calculate the percentage by individual store
      [Store] = stor_name
     ,[State] = state
     ,[Total By Store] = Sum(Sales.qty)
     ,[Grand Total] = @GrandTotal
     ,[Percentage by Store] = str((100 * Sum(Sales.qty)) / @GrandTotal, 5, 2) + '%'
     Into tRptSalesByStore
     From Pubs.dbo.Sales Join Pubs.dbo.Stores 
      On Stores.stor_id = Sales.stor_id
     Group by stor_name, state;

    Select -- Join the two temp tables to create complex report data
       SS.Store
     , SS.State
     , SS.[Total By Store]
     , S.[Total By State]
     , S.[Grand Total]
     , SS.[Percentage By Store]
     , S.[Percentage by State]
    Into tRptSalesByStoreAndState
    From tRptSalesByState as S
    Join tRptSalesByStore as SS
     on s.State = ss.State

    -- Return the other results as well!
    --Select * From tRptSalesByState; 
    --Select * From tRptSalesByStore;
    --Select * From tRptSalesByStoreAndState;

   Return
End
go

Exec pRptCreateSalesReportDataTables;
go
Declare @State char(2) = 'CA', @Store varchar(50) = 'News & Brews';
Select * From tRptSalesByState Where [State] = @State; 
Select * From tRptSalesByStore Where [State] = @State and [Store] = @Store;
Select * From tRptSalesByStoreAndState Where [State] = @State and [Store] = @Store;

--[ Pivoting Data ] --
-- Code to Create and Populate the PivotOrders Table
IF OBJECT_ID('dbo.PivotOrders', 'U') IS NOT NULL DROP TABLE dbo.PivotOrders;
GO

CREATE TABLE dbo.PivotOrders
(
  orderid   INT        NOT NULL,
  orderdate DATE       NOT NULL,
  empid     INT        NOT NULL,
  custid    VARCHAR(5) NOT NULL,
  qty       INT        NOT NULL,
  CONSTRAINT PK_Orders PRIMARY KEY(orderid)
);

INSERT INTO dbo.PivotOrders(orderid, orderdate, empid, custid, qty)
VALUES
  (30001, '20070802', 3, 'A', 10),
  (10001, '20071224', 2, 'A', 12),
  (10005, '20071224', 1, 'B', 20),
  (40001, '20080109', 2, 'A', 40),
  (10006, '20080118', 1, 'C', 14),
  (20001, '20080212', 2, 'B', 12),
  (40005, '20090212', 3, 'A', 10),
  (20002, '20090216', 1, 'C', 20),
  (30003, '20090418', 2, 'B', 15),
  (30004, '20070418', 3, 'C', 22),
  (30007, '20090907', 3, 'D', 30);

SELECT * FROM dbo.PivotOrders;


-- Query against Orders, grouping by employee and customer
SELECT empid, custid, SUM(qty) AS sumqty
FROM dbo.PivotOrders
GROUP BY empid, custid;

-- Query against Orders, grouping by employee, pivoting customers,
-- aggregating sum of quantity
SELECT empid,
  SUM(CASE WHEN custid = 'A' THEN qty END) AS A,
  SUM(CASE WHEN custid = 'B' THEN qty END) AS B,
  SUM(CASE WHEN custid = 'C' THEN qty END) AS C,
  SUM(CASE WHEN custid = 'D' THEN qty END) AS D  
FROM dbo.PivotOrders
GROUP BY empid;

-- A equivalent of previous query using the native PIVOT operator
SELECT empid, A, B, C, D
FROM ( -- NOTE we use a sub-select to get the data we want to Pivot, This defines the Grouping on ONLY empid, custid, qty
	  SELECT empid, custid, qty FROM PivotOrders) AS D
  PIVOT(SUM(qty) FOR custid IN(A, B, C, D)) AS P;  -- This will implicitly put DATA in columns with the same NAME

-- Query demonstrating the problem with implicit grouping
SELECT empid, A, B, C, D
FROM PivotOrders -- Now the Grouping is on All the columns, including ORDERID and ORDERDATE
  PIVOT(SUM(qty) FOR custid IN(A, B, C, D)) AS P;  -- This will implicitly put DATA in columns with the same NAME

-- Logical equivalent of previous query
SELECT empid,
  SUM(CASE WHEN custid = 'A' THEN qty END) AS A,
  SUM(CASE WHEN custid = 'B' THEN qty END) AS B,
  SUM(CASE WHEN custid = 'C' THEN qty END) AS C,
  SUM(CASE WHEN custid = 'D' THEN qty END) AS D  
FROM PivotOrders
GROUP BY orderid, orderdate, empid; -- Note that ORDERID and ORDERDATE is now included

-- Query against Orders, grouping by customer, pivoting employees,
-- aggregating sum of quantity
SELECT custid, [1], [2], [3]
FROM (SELECT empid, custid, qty FROM PivotOrders) AS D
  PIVOT(SUM(qty) FOR empid IN([1], [2], [3])) AS P;


--[ Unpivoting Data ]--
-- Code to create and populate the EmpCustOrders table
IF OBJECT_ID('dbo.EmpCustOrders', 'U') IS NOT NULL DROP TABLE dbo.EmpCustOrders;

CREATE TABLE dbo.EmpCustOrders
(
  empid INT NOT NULL
    CONSTRAINT PK_EmpCustOrders PRIMARY KEY,
  A VARCHAR(5) NULL,
  B VARCHAR(5) NULL,
  C VARCHAR(5) NULL,
  D VARCHAR(5) NULL
);

INSERT INTO dbo.EmpCustOrders(empid, A, B, C, D)
  SELECT empid, A, B, C, D
  FROM (SELECT empid, custid, qty
        FROM PivotOrders) AS D
    PIVOT(SUM(qty) FOR custid IN(A, B, C, D)) AS P;

SELECT * FROM dbo.EmpCustOrders;

-- Unpivoting with Standard SQL
-- Unpivot Step 1: generate copies
SELECT *
FROM dbo.EmpCustOrders
  CROSS JOIN (VALUES('A'),('B'),('C'),('D')) AS Custs(custid);

-- Unpivot Step 2: extract elements
SELECT empid, custid,
  CASE custid --<< This is the new Column Name
    WHEN 'A' THEN A
    WHEN 'B' THEN B
    WHEN 'C' THEN C
    WHEN 'D' THEN D    
  END AS qty
FROM dbo.EmpCustOrders
  CROSS JOIN (VALUES('A'),('B'),('C'),('D')) AS Custs(custid);

-- Unpivot Step 3: eliminate NULLs
SELECT *
FROM (SELECT empid, custid,
        CASE custid
          WHEN 'A' THEN A
          WHEN 'B' THEN B
          WHEN 'C' THEN C
          WHEN 'D' THEN D    
        END AS qty
      FROM dbo.EmpCustOrders
        CROSS JOIN (VALUES('A'),('B'),('C'),('D')) AS Custs(custid)) AS D
WHERE qty IS NOT NULL; --<< This get rid of the nulls

-- Unpivoting with the Native T-SQL UNPIVOT Operator
-- Query using the native UNPIVOT operator
SELECT empid, custid, qty
FROM dbo.EmpCustOrders
  UNPIVOT(qty FOR custid IN(A, B, C, D)) AS U;
  

-- Grouping Sets
-- Four queries, each with a different grouping set
SELECT empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY empid, custid;

SELECT empid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY empid;

SELECT custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY custid;

SELECT SUM(qty) AS sumqty
FROM PivotOrders;

-- Unifying result sets of four queries
SELECT empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY empid, custid

UNION ALL

SELECT empid, NULL, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY empid

UNION ALL

SELECT NULL, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY custid

UNION ALL

SELECT NULL, NULL, SUM(qty) AS sumqty
FROM PivotOrders;

---------------------------------------------------------------------
-- GROUPING SETS Subclause

-- Using the GROUPING SETS subclause (Same Data as above, but easier to read and faster!)
SELECT empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY
  GROUPING SETS
  (
    (empid, custid), -- First Group Set
    (empid), -- Second
    (custid), -- Third
    () -- Fourth
  ) ;


-- Using the CUBE and Rollup subclause 
--- (Implicitly create group sets, based on all possible combinations based on the column list !)
SELECT empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY CUBE(empid, custid);

-- Using the ROLLUP subclause (Allows greater control!)
SELECT 
  YEAR(orderdate) AS orderyear,
  MONTH(orderdate) AS ordermonth,
  DAY(orderdate) AS orderday,
  SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY ROLLUP(YEAR(orderdate), MONTH(orderdate), DAY(orderdate));


--[Usiing GROUPING and GROUPING_ID Function ]--
SELECT empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY CUBE(empid, custid);

SELECT
  GROUPING(empid) AS grpemp, -- Returns 0 with part of a group, but 1 when NULL
  GROUPING(custid) AS grpcust,
  empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY CUBE(empid, custid);

-- This will return
 --0 when both Employee ID IS there AND Customer ID IS there
 --1 when Employee ID is there BUT Customer ID IS NOT there
 --2 when Employee ID is NOT there BUT Customer ID IS there
 --3 when Employee ID is NOT there BUT Customer ID IS NOT there
SELECT
  GROUPING_ID(empid, custid) AS groupingset,
  empid, custid, SUM(qty) AS sumqty
FROM PivotOrders
GROUP BY CUBE(empid, custid);


-- Cross and Outer APPLY with a UDF
/*
APPLY Operators
Objectives:
 �Use CROSS APPLY with subqueries
 �Use OUTER APPLY with subqueries
 �Use CROSS APPLY with table-valued functions
 �Use OUTER APPLY with table-valued functions

CROSS APPLY and OUTER APPLY let you call up a table-valued function 
	for each row returned by the table used in the query.

CROSS APPLY returns data only if the row being processed from the table 
	named on the left side of the operator matches data from the 
	table-valued function or subquery on the right side of the operator.

OUTER APPLY returns a row from the table named on the left side of the 
	operator even if it does not match data from the table-valued 
	function or subquery on the right side of the operator. It 
	behaves much like an OUTER JOIN operation.

Syntax

  {table expression} CROSS APPLY {correlated subquery}

  {table expression} OUTER APPLY {correlated subquery}

  {table expression} CROSS APPLY {table-valued function}

  {table expression} OUTER APPLY {table-valued function}
*/
Create Function Sales.MostRecentOrders(@CustID as int)
Returns Table
as
Return 
	Select Top (3) SalesOrderID, OrderDate
	From Sales.SalesOrderHeader
	Where CustomerID = @Custid
	Order By OrderDate Desc

-- Use the Table Function with CROSS APPLY --
Select Name as 'Customer' , MostRecent.*
From Sales.Store Cross Apply Sales.MostRecentOrders(CustomerID)
as MostRecent
Where Name Like 'A%'

-- Use the Table Function with OUTER APPLY --
Select Name as 'Customer' , MostRecent.*
From Sales.Store Outer Apply Sales.MostRecentOrders(CustomerID)
as MostRecent
Where Name Like 'A%'

'*** Functions for ETL Processing ***'
-----------------------------------------------------------------------------------------------------------------------
-- Function can help 
-- if you need to EXTRACT data from a SOURCE,
Create -- Drop
Table StagingForCustomers 
 (Name Varchar(100), Phone Varchar(100));
go
Insert Into StagingForCustomers(Name, Phone)
 Values ('Bob Smith', '(206)555-1212'), ('Sue Jones', '(425)123-4567')
go

-- then TRANSFORM that data,
Create Function fGetFirstName(@Name varchar(100))
 Returns nChar(5)
 As
 Begin
  Return(------------ Start From Zero
   Select FirstName = SubString(@Name,0,PatIndex('% %',@Name) + 1) 
  )
 End  
go

Create Function fGetLastName(@Name varchar(100))
 Returns nChar(5)
 As
 Begin
  Return(------------- Start From First Space 
   Select [LastName] = SubString(@Name,PatIndex('% %',@Name) + 1,100)
  )
 End  
go

Create Function fGetAreaCode(@Phone varchar(50))
 Returns nChar(5)
 As
 Begin
  Return(------------ Start From end parenthesis
   Select AreaCode = SubString(@Phone,0,PatIndex('%)%',@Phone) + 1) 
  )
 End  
go

Create Function fGetPhoneNumber(@Phone varchar(100))
 Returns nVarchar(100)
 As
 Begin
  Return(------------- Start From First parenthesis 
   Select [PhoneNumber] = SubString(@Phone,PatIndex('%)%',@Phone) + 1,100)
  )
 End  
go

-- before you LOAD it into its DESTINATION!
Create Table Customers 
 (CustomerID int Primary Key Identity
 ,CustomerFirstName nVarchar(100)
 ,CustomerLastName nVarchar(100)
 ,PhoneAreaCode nVarchar(100)
 ,PhoneNumber nVarchar(100)
 );
go

Insert Into Customers(CustomerFirstName,CustomerLastName,PhoneAreaCode,PhoneNumber)
Select 
 [CustomerFirstName] = dbo.fGetFirstName(Name) 
,[CustomerLastName] = dbo.fGetLastName(Name)
,[CustomerPhoneAreaCode] = dbo.fGetAreaCode(Phone) 
,[CustomerPhoneNumber] = dbo.fGetPhoneNumber(Phone) 
 From StagingForCustomers;
go

Select * From Customers;
